package com.ani.springbootstarter.topic;



import java.util.Arrays;
import java.util.List;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TopicController {
	
	@RequestMapping("/topics")
	public List<Topic> getAllTopics() {
	
		
		return Arrays.asList(
				new Topic("1", "Spring1", "description1"),
				new Topic("2", "Spring2", "description2"),
				new Topic("3", "Spring3", "description3"),
				new Topic("4", "Spring4", "description4"),
				new Topic("5", "Spring5", "description5")

				);
	}

}
