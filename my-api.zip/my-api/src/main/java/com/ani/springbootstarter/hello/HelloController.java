package com.ani.springbootstarter.hello;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class HelloController {

	//Get mapping and RequestMapping are same but if u r using it for method it is preferred
	//to use GetMapping() and for class use RequestMapping()
	@RequestMapping("/hello")
	public String sayHi() {
		return "Hii";
		
	}
	
	
	@GetMapping("/ack")
	public static String ack() {
		return "This is the valid page for acknowledgment ";
	}
	@RequestMapping("")
	public String sayHome() {
		return "Home Page";
		
	}
	
	@RequestMapping("/nothing")
	public String sayNo() {
		return "Nothing";
				
	}
	
	@RequestMapping("/nothingg")
	public String sayNbo() {
		return "Nothinrtyghujg";
				
	}
	
	@GetMapping("/html")
	public String hello(Model model, @RequestParam(value="name", required=false, defaultValue="World") String name) {
        model.addAttribute("name", name);
        String s = "<html><input type=\"text\" placeholder=\"Enter Username\" name=\"uname\" required></br>"
        		+ "</br><input type=\"password\" placeholder=\"Enter Password\" name=\"psw\" required></br>"
        		+ " <h3>Just trying to fetch html data </h3> </html>";
        return s;
    }

	@GetMapping("/html_w/o_model_class")
	public String sayNroo() {
		String s = "<html><input type=\"text\" placeholder=\"Enter Username\" name=\"uname\" required></br>"
        		+ "</br><input type=\"password\" placeholder=\"Enter Password\" name=\"psw\" required></br>"
        		+ " <h3>Just trying to fetch html without Model class </h3> "
        		+ "<button type=\"submit\">Login</button>"
        		+ "</html>";
        return s;
				
	}
	
	@GetMapping("/nyo")
	public String sayNyo() {
		return "Nyo";
				
	}

}
